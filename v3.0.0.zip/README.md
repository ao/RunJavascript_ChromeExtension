# RunJavascript_ChromeExtension

A simple Chrome Extension that allows you to run some Javascript each time you are on that domain.

https://chrome.google.com/webstore/detail/run-javascript/lmilalhkkdhfieeienjbiicclobibjao

## Get help
https://blog.ataiva.com/run-javascript-chrome-extension-help/
